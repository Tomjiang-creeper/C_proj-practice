
int main()
{

int max(int a, int b)
{
    int x;
    // int i;
    // scanf("%d", &i);
    //不太会用
if (a>b){
    x = a;
}else{
    x = b;
}
    return x;
}
}
//原来main函数内部可以不用严格遵守缩进