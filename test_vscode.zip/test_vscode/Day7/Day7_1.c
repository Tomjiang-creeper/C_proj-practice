#include <stdio.h>

int main()
{
    int x = 0;
    int a = 1;
    int b = 2;
    if (a>b){
        x = a;
        printf("%d",x);
    } else{
        x = b;
        printf("%d",x);
    }
    return 0;
}
