#include<stdio.h>

int main()
{
    printf("Hello,world!\n");
    
    //注意，即使没有return 0，这里也会被识别为有return 0的代码（C99的规定），但是会隐性地返回一个0
}
