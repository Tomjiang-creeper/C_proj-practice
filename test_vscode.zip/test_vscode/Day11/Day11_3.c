# include <stdio.h>
#define MAX 100
//每5个换一行，输出兔子数列
int main(void)
{
    int i, n;
    int f[MAX] = {1,1};

    printf("Enter n to calc:");
    scanf("%d", &n);
    if(n>=1&&n<=100){
        for(i = 2; i < n; i ++){
            f[i]=f[i-1]+f[i-2];
    }
    for(i = 0;i < n; i++){
        printf("%9d ",f[i]);
        //这个前面的数字是决定空出几个格子的
        if((i+1)%5==0){
            printf("\n");
        }//要把这个输入空格的代码塞进循环，因为这也是每5个输出一个的小循环
    }
    if(n>=45){
        printf("\nWarning, n is too large and the table might be messy.\n");
    }
    }else{
    printf("Please enter a correct n.\n");
    
}
return 0;
}

//还是自己写的靠谱一些