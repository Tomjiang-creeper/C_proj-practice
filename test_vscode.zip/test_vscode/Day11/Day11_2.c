# include <stdio.h>

# define MAXN 46
int main(void)
{
    int i,n;
    int f[MAXN] = {1,1};
    printf("Enter n:\n");
    scanf("%d", &n);
    if(n>=1&&n<=46){
        for (i = 2;i < 10;i++){
            f[i] = f[i-1] + f[i-2];
        }
        for (i = 0;i < 10;i++){
            printf("%6d", f[i]);
            if ((i+1)%5==0){
                printf("\n");
            }
        }
        if (n%5!=0){
        printf("\n");
    }
    
    }else{
        printf("Invalid Value.\n");
    }
    return 0;
}