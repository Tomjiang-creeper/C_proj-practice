# include <stdio.h>
int main(void)
{
    char ch;

    printf("Please input character:\n");
    ch = getchar();

    while(ch != '\n'){
        putchar(ch);
        /*输出一个ch,如果没有getchar的命令，他会一直
        输出刚才输入的*/
        ch = getchar();
        //再次调用getchar，为下次scanf做准备
    }
    return 0;
}