# include <stdio.h>

int main()
{
    char ch;
    printf("Please input the characters:\n");
    ch = getchar();

    while(ch != '\n'){
        if(ch <= 'z' && ch >= 'a'){
            ch = ch - 'a' + 1 + 'A';
        }else if(ch <= 'Z' && ch >= 'A'){
            ch = ch - 'A' + 1 + 'a';
        }
        putchar(ch);
        ch = getchar();
        /*再次进行循环，如果不是回车的话就一直输入,
        这个结构非常值得学习*/
        }
}
