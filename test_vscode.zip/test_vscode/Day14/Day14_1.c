# include <stdio.h>

int main(void)
{
    int a, b;
    printf("input a, b:");
    scanf("%x%d", &a, &b);
    printf("%d %5d\n", a, b);

    return 0;
}