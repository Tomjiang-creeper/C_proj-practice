#include<stdio.h>

int main()
{
    int age = 10;
    int height = 172;
    printf("I'm %d years old.\n", age);
    printf("I'm %dcm tall.\n", height);
    // puts("I am %d years old\n", age);
    // puts("I am %d inches tall\n", height);
    //puts函数不支持格式化字符串
    return 0;
}