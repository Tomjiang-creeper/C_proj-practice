int main(int argc, char *argv[])
{
    puts("Hello world!\nHello world!");

    return 0;
}
