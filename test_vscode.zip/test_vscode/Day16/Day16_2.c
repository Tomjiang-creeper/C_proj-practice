# include <stdio.h>
# include <string.h>
#define MAX 10
int main(void)
{
    char a[MAX] = "Hello";
    char * pch = "Array";
    
    /*如果数组没有定义容量的话，调用strcpy函数的话会警告，
    因为有缓冲区溢出的风险*/
    printf("%s\n", a);
    printf("%s\n", pch);

    /*
    如果string头文件没有事先输入的话会发出警告
    */
    strcpy(a, "World");
    pch = "Point";
    printf("%s\n", a);
    printf("%s\n", pch);

    return 0;
}