# include <stdio.h>
# include <string.h>

int main() 
{
    char s1[60], s2[50], p[100] = "Happy";
    /*这里括号里面的数规定了字符串的长度，
    以免引发不必要的错误*/
    strcpy(s1, "Leo");
    strcpy(s2, "key");
    printf("%s\n%s\n",s1,s2);
    strcat(s2,"Answer");
    strcpy(s1, p);
    printf("%s\n%s\n",s1,s2);

    return 0;
}