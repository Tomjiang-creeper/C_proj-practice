# include <stdio.h>

int main(void)
{
    char ch[] = "array";
    char * sa = "point";
    printf("%s\n", ch);
    printf("%s\n", sa);
    printf("%s\n", "string");

    printf("%s\n", ch+2);
    printf("%s\n", sa+3);
    printf("%s\n", "string"+1);
    /*这里的加指的是在原来字符串长度
    的基础上往后推几个*/
    return 0;
}