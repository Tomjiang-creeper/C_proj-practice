# include <stdio.h>

int main(void)
{
    int input;
    int expectaion = 10;
    printf("Enter a number to guess:\n");
    scanf("%d", &input);
    
    if(input==expectaion){
        printf("Good!\n");
    } else{
    for (;input != expectaion;){
        /*就是这个代码，可能是因为for要接受三个参数，如果只有一个参数的话会报错，
        如果只有一个参数需要限制的话，那么需要两个分号补全
        */
        if(input<expectaion){
            printf("Try again\n");
            scanf("%d", &input);
        }else{
            //注意，这里如果还加条件的话就会报错
            printf("Try again\n");
            scanf("%d", &input);
        }
        }
    printf("Good");
    }
    return 0;
    
}
//而且这个程序如果猜错了只能猜第二次，不会循环让我们猜
//10.11下午，代码已修正，已经可以做到无限循环，而且还修正了循环过后没有Good提示的问题