# include <stdio.h>
# include <math.h>

int main(void)
{
    int count, number, __number;
    count = 0;
    printf("Enter a number:");
    scanf("%d", &number);
    __number = number;
    //对数据进行保护，用了python的方法
    if(number<0){
        __number = -__number;
    }
    do{
        count ++;
        __number = __number/10;

    }while(number != 0);
    printf("It contians %d digits.\n", count);
    
    return 0;
}
//啥意思啊，没搞懂while是怎么用的