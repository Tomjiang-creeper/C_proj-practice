# include <stdio.h>
//计算输入数组的位数
int main()
{
    int count, number, __number;

    count = 0;
    printf("Enter a number to count:\n");
    scanf("%d", &number);
    __number = number;
    if (number < 0){
        __number = -__number;
    }
    for(count = 0;__number >= 0.1;count++){__number = __number / 10;
    }
    printf("The number is %d", count);
}
/*还是自己编出来的靠谱一些，
而且测试过负数也是可以正常运行的*/
