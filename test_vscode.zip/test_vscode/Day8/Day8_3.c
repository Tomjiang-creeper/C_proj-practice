# include <stdio.h>
int main(void)
{
    int n, i;
    int denominator, flag;
    double sum, item; 
    //测试过，这一行很关键，如果是int类型的话输出结果一直为0，不知道为什么
    
    printf("Enter n for calculate:\n");
    scanf("%d", &n);
    flag = 1;
    denominator = 1;
    item = 1;
    sum = 0;
    for(i=1;i<=n;i++){
        sum = sum + item;
        flag = -flag;
        denominator = denominator + 2;
        item = flag * 1.0/ denominator;     
    }
    printf("sum = %f\n", sum);
    return 0;
}
