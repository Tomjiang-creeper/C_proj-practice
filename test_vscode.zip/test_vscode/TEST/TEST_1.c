# include <stdio.h>
int main(void)
{
    int i, n;
    i = 1;
    n = 1;

    for (i = 1; n <= 100; n++){
        i = i + 1;
        if (n % 15 == 0){
            printf("FizzBuzz,");
        //交际并集，如果3，5比15前的话，15永远就只会输出Fizz
        }else if(n % 5 == 0){
            printf("Buzz,");
        }else if(n % 3 == 0){
            printf("Fizz,");
        }else{  
        printf("%d,",n);
        
}
}
}