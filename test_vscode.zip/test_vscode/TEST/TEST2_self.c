# include <stdio.h>

int main(void)
{
    int i;
    int n;
    char input[n];
    char result;
    printf("Input characters:\n");
    input[n] = getchar();
    result = input[n];
    putchar("%s", result);
    
    
    
}

char f_turn(char[i]){

}