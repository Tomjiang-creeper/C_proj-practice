# include<stdio.h>
int main()
{
    int i, n, m;
    printf("Enter the str number:\n");
    scanf("%d",&n);
    for (i = 1;i<=n;i++){
    printf("Enter each str:");
    scanf("%d",&m);
    }
}
/*pro:字符串的数据类型，数组的数据类型*/