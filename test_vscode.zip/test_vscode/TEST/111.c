
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int number, guess, attempts = 0;
    srand(time(0)); // 使用当前时间作为随机数种子
    number = rand() % 100 + 1; // 生成1到100之间的随机数

    printf("欢迎来到猜数字游戏！\n");
    printf("我已经想好了一个1到100之间的数字。你能猜到它是什么吗？\n");

    do {
        printf("请输入你的猜测：");
        scanf("%d", &guess);
        attempts++;

        if (guess > number) {
            printf("太高了！再试一次。\n");
        } else if (guess < number) {
            printf("太低了！再试一次。\n");
        } else {
            printf("恭喜你！你猜对了！你一共用了%d次机会。\n", attempts);
        }
    } while (guess != number);

    return 0;
}

