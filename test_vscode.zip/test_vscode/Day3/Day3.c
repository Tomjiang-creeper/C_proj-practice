#include <stdio.h>

int main()
{
    int a;
    int b;
    int c;

    __asm__
        {
        mov a, 3
         mov b, 4
         mov eax, a
           add eax, b
        mov c, eax
        }

    printf("%d\n",c);
    return 0;
}

/*
ctrl+k + ctrl+c注释
ctrl+k + ctrl+u取消注释 
*/
