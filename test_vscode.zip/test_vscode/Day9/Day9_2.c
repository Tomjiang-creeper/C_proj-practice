# include <stdio.h>
# include <math.h>

int main()
{
    int i, limit, m;
    printf("Enter a number to calculate:\n");
    scanf("%d", &m);
    if(m<1){
        printf("Nope.\n");

    }else if(m==2){
        printf("%d is prime number.\n", m);

    }else{
        limit = sqrt(m)+1;
        for(i = 2; i <= limit; i++){
            if(m%i == 0){
                break;
            }
        }
        if( i > limit){
            printf("%d is a prime number.\n",m);
        }else{
            printf("Nope\n");
        }
    }
    return 0;
}
//一个计算素数的程序，不太懂是怎么看的