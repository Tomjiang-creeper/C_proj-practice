# include <stdio.h>
# include <stdlib.h>
# include <time.h>
int main(void)
{
    int count = 0, flag, number, expection;
    srand(time(0));
    expection = rand()%100 + 1;
    flag = 0;
    while(count < 7){
        printf("Enter your number:\n");
        scanf("%d", number);
        count++;
        if (number==expection){
            printf("Lukcy\n");
            flag = 1;
            break;
        }else if(number > expection){
            printf("Too big\n");
        }else{//这里的else不能带条件，不然会报错
            printf("Too small\n");
        }
    }
    if(flag==0){
        printf("Game over!\n");
    }
    return 0;
}
//狗屎，系统给的数不在到100之间。