# include <stdio.h>
int main(void)
{
    int i, mark, max, n;
    printf("Enter n:\n");
    scanf("%d", &n);
    printf("Enter first marks:\n");
    scanf("%d", &mark);
    max = mark;
    for (i = 1;i < n;i++){
        printf("Enter next number:\n");
        scanf("%d",&mark);
        if (max<mark){
            max = mark;
        }
    }
    printf("The max number is %d.\n", max);
    return 0;
}
/*一个很巧妙的思想，先把max现实化，然后一一比较，
而不是把所有数总和到一起比较*/
