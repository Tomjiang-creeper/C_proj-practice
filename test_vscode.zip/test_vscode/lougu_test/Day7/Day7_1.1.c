#include <stdio.h>

int main(void)
{
    char str[256];	//字符串
    int boy_count = 0;	//boy的个数，初值为0
    int girl_count = 0;	//girl的个数，初值为0

    scanf("%s", str);

    for (int i = 0; str[i] != '\0'; i++)
    {
        if (str[i] == '.')
        {
            continue;
        }
        else if (str[i] == 'b' && str[i + 1] == 'o' && str[i + 2] == 'y')
        {
            boy_count++;

            str[i] = '.';
            str[i + 1] = '.';
            str[i + 2] = '.';
            //这里可能是为了防止后面数重复
        }
        else if ((str[i] == 'b' && str[i + 1] == 'o') 
            || (str[i] == 'o' && str[i + 1] == 'y'))
        {
            boy_count++;

            str[i] = '.';
            str[i + 1] = '.';
        }
        else if (str[i] == 'b' 
            || str[i] == 'o' 
            || str[i] == 'y')
        {
            boy_count++;

            str[i] = '.';
        }
        else if (str[i] == 'g' && str[i + 1] == 'i' && str[i + 2] == 'r' && str[i + 3] == 'l')
        {
            girl_count++;

            str[i] = '.';
            str[i + 1] = '.';
            str[i + 2] = '.';
            str[i + 3] = '.';
        }
        else if ((str[i] == 'g' && str[i + 1] == 'i' && str[i + 2] == 'r') ||
            (str[i] == 'i' && str[i + 1] == 'r' && str[i + 2] == 'l'))
        {
            girl_count++;

            str[i] = '.';
            str[i + 1] = '.';
            str[i + 2] = '.';
        }
        else if ((str[i] == 'g' && str[i + 1] == 'i') ||
            (str[i] == 'r' && str[i + 1] == 'l') ||
            (str[i] == 'i' && str[i + 1] == 'r'))
        {
            girl_count++;

            str[i] = '.';
            str[i + 1] = '.';
        }
        else if (str[i] == 'g'
            || str[i] == 'i'
            || str[i] == 'r'
            || str[i] == 'l')
        {
            girl_count++;

            str[i] = '.';
        }
    }

    printf("%d\n%d\n", boy_count, girl_count);

    return 0;
}