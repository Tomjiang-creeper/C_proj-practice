# include <stdio.h>
# include <string.h>

#define l 255
int main(void)
{

    int n;
    int i;
    int boy = 0,girl = 0;
    //最开始要定义boy和girl的值
    char ipt[l];
    //脑抽了是吧，定义数组不用等号
    gets(ipt);
    n = strlen(ipt);

    for (i = 0; i < n; i++){
        if (ipt[i] != '.'){
            if (ipt[i]=='b' && ipt[i+1]=='o' && ipt[i+2]=='y'){
                boy++;
            }if(ipt[i]=='g' && ipt[i+1]=='i' && ipt[i+2]=='r' && ipt[i+3]=='l'){
                girl++;
            }
        }else{
            continue;
        }
    }
    printf("%d\n%d",boy,girl);

    return 0;
}
