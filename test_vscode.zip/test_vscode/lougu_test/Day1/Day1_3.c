# include <stdio.h>

int main(void)
{
    char n;
    scanf("%c", &n);
    printf("  %c  \n %c%c%c \n%c%c%c%c%c",n,n,n,n,n,n,n,n,n);

    return 0;
}