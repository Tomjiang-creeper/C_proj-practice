# include <stdio.h>
# include <string.h>

int main(void)
{
    char ch[10];
    gets(ch);
    int n;
    n = strlen(ch);
    int answer = 0;
    for(int i=0;  i < n; i++){
        if(ch[i]>='A'&&ch[i]<='Z')
		answer++;
		if(ch[i]>='a'&&ch[i]<='z')
		answer++;
		if(ch[i]>='0'&&ch[i]<='9')
		answer++;
    }

    printf("%d", answer);

    return 0;

}