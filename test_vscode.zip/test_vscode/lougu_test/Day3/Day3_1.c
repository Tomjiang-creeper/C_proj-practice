# include <stdio.h>
# include <string.h>

#define MAX 100
int main(void)
{
    int i, j = 0, n;
    char word[MAX];

        scanf("%s",&word[i]);
    

    int length = strlen(word);

    for(n=0;n<length;n++){
        if(word[n] == word[n+1]){
            j++;
        }
    }
    printf("The max number of char is %d",j);
    return 0;
}