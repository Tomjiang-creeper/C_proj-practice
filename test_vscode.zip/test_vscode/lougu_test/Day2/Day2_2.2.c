# include <stdio.h>

int main(void)
{
    char in[100];
    int n, j;
    scanf("%d""%s", &n, &in);
    //为什么这里in前面不用&符号,试过如果加了&没有影响
    for(j = 0; in[j] != '\0'; j++){
        putchar((in[j] - 'a' + n)%26 + 'a');
    }
}
/*
#24.10.23

洛谷的编译卡运行时间
这意味着需要花更少的代码去完成一项任务
要求更高了
*/