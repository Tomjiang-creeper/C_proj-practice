# include <Stdio.h>

int main(void)
{
    int n;
    char paswd;
    scanf("%d", &n);
    getchar();
    //为什么这里不能paswd = getchar(),还是有点不理解
    while(paswd != '\n'){
        
        paswd = paswd + n;
        putchar(paswd);
        paswd = getchar();
    }
    return 0;
}



