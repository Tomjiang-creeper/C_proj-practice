# include <stdio.h>

int main(void)
{
    char ch;
    ch = getchar();
    //如果没有这一行也是可以正常使用的，不知道为什么
    //第二个问题就是，如果单纯就是getchar的话输出会丢掉一个字符
    while(ch != '\n'){
        if(ch >= 'a' && ch <= 'z'){
            ch = ch - 'a' + 'A';
        }
        putchar(ch);
        ch = getchar();
    }
    
    return 0;
}