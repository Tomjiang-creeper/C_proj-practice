/*
任务目标，做出一个识别九键要按多少次的程序
*/

# include <stdio.h>
# include <string.h>

int main(void)
{
    char ch[201];
    int n;
    int m = 0;
    gets(ch);
    n = strlen(ch);
    
    for (int i = 0; i < n; i++){
        if(ch[i]=='a' || ch[i]=='d' || ch[i]=='g' || ch[i]=='j' || ch[i]=='m' || ch[i]=='p' || ch[i]=='t' || ch[i]=='w')
        m++;
        
        if(ch[i]=='b' || ch[i]=='e' || ch[i]=='h' || ch[i]=='k' || ch[i]=='n' || ch[i]=='q' || ch[i]=='u' || ch[i]=='x')
        m+=2;
        
        if(ch[i]=='c' || ch[i]=='f' || ch[i]=='i' || ch[i]=='l' || ch[i]=='o' || ch[i]=='r' || ch[i]=='v' || ch[i]=='y')
        m+=3;
        
        if(ch[i]=='s' || ch[i]=='z')
        m+=4;
        
        if(ch[i]==' ')
        m++;
    }

        printf("%d", m);

        return 0;
}

