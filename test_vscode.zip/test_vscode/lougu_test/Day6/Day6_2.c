# include <stdio.h>


int main(void)
{
    int n;
    //接收字符串长度
    scanf("%d",&n);
    char str[101];
    scanf("%s",&str);
    for(n > 0; int i = 0; i++){
        if str[i] == 'v'{
            if str[i+1] != 'v'{
                
            }

        }
    }
}