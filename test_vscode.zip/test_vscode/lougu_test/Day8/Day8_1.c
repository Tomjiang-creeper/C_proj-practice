# include <stdio.h>
# include <string.h>
#define MAXN 100

int main(void)
{
    char group[MAXN];
    char star[MAXN];

    int i;
    int n;

    int lengroup;
    int lenstar;

    gets(group);
    gets(star);
    
    lengroup = len(group);
    for(i = 0; i < lengroup; i++){
        if group[i] = 'A'{
            num = 1;
        }

    }
}
