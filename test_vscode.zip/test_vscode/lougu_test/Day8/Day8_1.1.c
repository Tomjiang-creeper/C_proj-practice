# include <stdio.h>

int main(void)
{
    char a[7] = "";
    char b[7] = "";

    scanf("%[A-Z]\n%[A-Z]",&a,&b);
    int c = 1;
    int d = 1;
    int i = 0;

    for(;a[i]!='\0';){
        c = c * (a[i]-'A'+1);
        i++;
    }
    c = c % 47;
    i = 0;
    /*一个变量多次使用，只要初始化了就行*/
    for(;b[i]!='\0';){
        d = d * (b[i]-'A'+1);
        i++;
    }
    d * d % 47;
    if (c!=d){
        printf("STAY");
    }
    else{
        printf("Go");
    }
}
