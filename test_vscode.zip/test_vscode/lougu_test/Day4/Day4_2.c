# include <stdio.h>
# include <string.h>
#define MAX 101

int main(void)
{
    int n, i, length;
    char ch[MAX];
    gets(ch);
    //gets函数可以跳过空格继续存储空格后面的字符串
    length = strlen(ch);
    for (i = 0; i < length; i++){
        if(ch[i] != ' ' && ch[i] != '\n'){
            n+=1;
        }
    }
    printf("%d",n);

    return 0;
}


