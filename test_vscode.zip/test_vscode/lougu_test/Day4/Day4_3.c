# include <stdio.h>
# include <string.h>
#define MAX 101
int main(void)
{
    int n, step;
    char word[MAX];
    int a, b, c;
    const char *word_one;
    scanf("%d",&step);
    if (step==4){
        scanf("%s",word);
    }
    scanf("%d",&n);
    switch(n){
        case 1:
        
        scanf("%s",&word_one);
        strcat(word, word_one);
        printf("%s",word);

        return 0;
        case 2:
        scanf("%d%d",&a,&b);
        //对字符串动手脚
        printf("");

        case 3:
        scanf("%d%s", &c, &word);
        
    }

}