# include <stdio.h>
# include <string.h>
#define MAX 101
int main(void)
{
    int length;
    int n, i;
    char ch[MAX];
    scanf("%s",ch);

    length = strlen(ch);

    for(i = 0; i<length;i++){
            if ((ch[i] >= 'A' && ch[i] <= 'Z') || 
            (ch[i] >= 'a' && ch[i] <= 'z') ||
            (ch[i] >= '0' && ch[i] <= '9')) {
            n++;
            }
    //今天收获：与运算，把本来很难放在一起的条件整合到一起
    }
    
    printf("%d",n);

    return 0;

}