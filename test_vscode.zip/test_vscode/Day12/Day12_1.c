# include <stdio.h>
int main()
{
    /*
    int i,*p; 定义指针P
    p = &i; 把i的地址赋给P
    p = 0; 把P的值赋为0
    p = NULL; 把P的值赋为0
    p = (int*)1732; 把绝对地址赋给指针
    */
}