# include <stdio.h>

int main(void)
{
    int a = 3, *p;
    p = &a;
    printf("a = %d, * p = %d p = %x\n",a,* p, p);
    * p = 10;
    printf("a = %d, * p = %d p = %x\n",a,* p, p);
    * p += 2;
    printf("a = %d, * p = %d p = %x\n",a,* p, p);
    //这里可以理解为，* p就是a
    scanf("%d", &a);
    printf("a = %d, * p = %d p = %x\n",a,* p, p);
    * p ++;
    printf("a = %d, * p = %d p = %x\n",a,* p, p);
    /*
    这里*p如果用的是%d,会输出地址，不知道为什么，
    然后这个地址会和p一样
    然后这个地址
    */
   return 0;
}