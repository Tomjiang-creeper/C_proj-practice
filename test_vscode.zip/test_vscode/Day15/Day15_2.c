# include <stdio.h.>

int main(void)
{
    int *n, i = 0;
    n = &i;
    printf("%x\n",n);
    printf("%d\n",* n);
    
    return 0;

}