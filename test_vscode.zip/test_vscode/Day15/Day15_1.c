# include <stdio.h>

int main(void)
{
    int x = 5342;
    int *p=NULL;

    p = &x;
    //这里p存储了x的地址
    printf("name->value:%d\n",x);

    printf("address:%x,value:%d\n",p, *p);
    //地址16进制好描述一点
    return 0;
}