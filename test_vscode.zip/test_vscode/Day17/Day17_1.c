# include <stdio.h>

struct student
{
    int num;
    char name[10];
    int computer, english, math;
    double average;

};

//注意这里有一个分号
int main(void)
{
    int n, i;
    struct student max, stu;
    /*
    这里有点没太弄懂
    */
    printf("Input student number n:");
    scanf("%d", &n);
    printf("Input student's number, name and scores.\n");
    for(i = 0; 1 <= n; i++){
        printf("No %d:", i);
        scanf("%d%s%d%d%d", &stu.num,stu.name,&stu.math,&stu.english,&stu.computer);
        stu.average = (stu.math + stu.english + stu.computer)/3.0;
    if(i == 1){
        max = stu;
    }else if(max.average<stu.average){
        max = stu;
    }
    }
    printf("num:%d, name:%s, average:%.2lf\n",max.num, max.name, max.average);

    return 0;
}