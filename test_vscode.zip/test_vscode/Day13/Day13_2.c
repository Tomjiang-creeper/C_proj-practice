# include <stdio.h>
//输入字符串，然后大小写相互变换
int main(void)
{
    char ch;
    printf("Input characters:\n");
    ch = getchar();
    printf("The capital char is:\n");
    while (ch!='\n'){
        if (ch>='A'&&ch <='Z'){
            ch = ch-'A'+'a';
        }else if (ch >='a'&&ch <='z'){
            ch = ch-'a'+'A';
        }
        putchar(ch);
        //输出字符串
        ch = getchar();
    }
    return 0;
}