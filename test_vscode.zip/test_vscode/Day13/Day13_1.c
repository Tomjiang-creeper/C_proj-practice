# include <stdio.h>
#define MAXN 10
int main(void)
{
    int i, index, n;
    int a[MAXN];

    printf("Enter n:");
    scanf("%d",&n);
    printf("Enter %d integers:",n);
    for (i = 0; i<n; i++){
        scanf("%d",&a[i]);
    }
    //这个结构可以用到TEST1上，输入字符串长度后输入字符串，存储进一个数组
    index = 0;
    for(i=0; i<n; i++){
        if (a[i]<a[index]){
            index = i;
            //这里不能加入等号，否则会因为index的值发生变化而取的不是第一次出现最小值的sub
        }
    }
    
    printf("min is %d \t sub is %d\n", a[index],index);
    // \t制表，不用打出这么多空格了
    return 0;

}