# include <stdio.h>

# define MAXN 6
# define MAXM 6

int main(void)
{
    int col, row, i, j, n, m;
    /*刻画n,m的变化————i,j,刻画区域:col,row,
    n,m单纯就是存储值的*/
    int a[MAXN][MAXM];

    printf("Enter m, n:\n");
    scanf("%d%d", &m, &n);

    printf("Enter %d numbers:\n",m * n);
    for (i=0;i<m;i++){
        for(j=0;j<n;j++){
            //两层嵌套循环时为了同时输入二维的数组
            scanf("%d", &a[i][j]);
        }
    }
    row = col = 0;
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            if(a[i][j]>a[row][col]){
                //已经犯过好多次错误了，注意条件判断中的大小比较
                row = i;
                col = j;
            }
        }
    }
    printf("max = a[%d][%d] = %d\n" ,row, col, a[row][col]);

    return 0;
}