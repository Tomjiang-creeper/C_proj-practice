# include <stdio.h>

int main()
{
    printf("Hello, \nworld!\n");
    printf("the result is:\n");
    printf("He said, \"I'm fine.\"\n");
    //这里的\"和\'的意思是转义为"和'，因为存在字符里面需要用到的情况
}