# include <stdio.h>

int main()
{
    int i = 0;
    char *states[] = {
        "1","2",
        "3","4"
    };
    int num_states = 4;

    for(i = 0; i < num_states; i++) {
        printf("state %d: %s\n", i, states[i]);
    }

    return 0;

}
