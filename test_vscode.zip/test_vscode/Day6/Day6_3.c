#include <stdio.h>

int main()
{
    printf("The size of an int is %d",sizeof(int));
    return 0;
}