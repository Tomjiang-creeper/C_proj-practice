# include <stdio.h>


int main()
{
    double f(int n, int r);
    //要先声明需要调用这个函数
    int r = 0;
    int n;
    int result;
    
    printf("Enter n to calc:\n");
    scanf("%d",&n);
    result = f(n, r);
    //这里不能把n,r的具体类型写出来，不然会报错
    printf("The result is %d.\n", result);
}
double f(int n, int r)
{
    double sum=0;
    for(r = 0; r <= n; r++)
    {
        sum = sum + n * r;
    }
    return sum;
    //这一句也很重要，不然到时候返回main函数的时候没有值了
}
/*
这段代码中存在一些问题：
1.在 main() 函数中的 int r = 0; 是多余的，因为你在调用 f(n,r) 
的时候并没有使用这个变量。
3.在 double f(int n, int r) 函数中，你需要初始化 sum 变量为 0 或者是忽略它，
因为在循环开始之前没有给它赋值会导致未定义的行为。
3.在 for 循环中，你的计算方式是错误的。你正在将 n 和 r 相乘并累加到 sum 中，
这并不是一个正确的数学公式或算法。如果你想要计算阶乘或者组合数等，请确保
使用正确的公式。
4.如果你想在 main() 函数中正确地传递参数给 f(n,r)，你需要先声明 r 并
赋予其一个初始值。
*/
