#include <stdio.h>
double calc(double r, double h);
int main()
{
    double height, radius, volume;
    printf("Enter radius and height:\n");
    scanf("%lf%lf", &radius, &height);
    volume=calc(radius,height);
    printf("Volume is %.3f\n",volume);

    return 0;
}

double calc(double r,double h)
{
    double result;
    result=3.14*r*r*h;
    return result;
}