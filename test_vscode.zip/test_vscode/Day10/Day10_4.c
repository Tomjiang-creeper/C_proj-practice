# include <stdio.h>

int main()
{
    int a = 0;
    int b = 10;
    if (!a){
        printf("a is 0, so !a true.\n");
    }
    if (!b){
        printf("This will not be printed because b is not 0.\n");
    }else{
        printf("b is not 0, so !b is false.\n");
    }
    int *ptr = NULL;
    if (!ptr){
        printf("The pointer is NULL.\n");
    }
    return 0;
}
/*
它是一个一元运算符，用来对一个操作数进行逻辑取反。
如果操作数为0（假），那么!运算符的结果将是1（真）；
如果操作数是非0值（真），那么结果将是0（假）。
*/