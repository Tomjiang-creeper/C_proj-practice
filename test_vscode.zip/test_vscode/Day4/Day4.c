/*
光标停在某行：ctrl+c、v会直接复制这一行
ctrl+backspace单词删除
tab键补全命令,也可以把大写的转为小写
移动多行：alt + 方向上下键
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(viod)
{
    char buf[1024];
    sprintf(buf, "%s", "abc");
}
